# src/tracking/byte_track.py
import numpy as np
from filterpy.kalman import KalmanFilter
from scipy.optimize import linear_sum_assignment
from typing import List, Dict, Tuple

class KalmanBoxTracker:
    """Kalman Filter for tracking bounding boxes"""
    
    def __init__(self, bbox, track_id, class_id):
        self.kf = KalmanFilter(dim_x=7, dim_z=4)
        
        # State: [x, y, s, r, x_dot, y_dot, s_dot]
        # where s = scale (area), r = aspect ratio
        self.kf.F = np.array([
            [1,0,0,0,1,0,0],
            [0,1,0,0,0,1,0],
            [0,0,1,0,0,0,1],
            [0,0,0,1,0,0,0],
            [0,0,0,0,1,0,0],
            [0,0,0,0,0,1,0],
            [0,0,0,0,0,0,1]
        ])
        
        self.kf.H = np.array([
            [1,0,0,0,0,0,0],
            [0,1,0,0,0,0,0],
            [0,0,1,0,0,0,0],
            [0,0,0,1,0,0,0]
        ])
        
        # Initialize with first detection
        self.kf.x[:4] = self.convert_bbox_to_z(bbox)
        self.time_since_update = 0
        self.id = track_id
        self.class_id = class_id
        self.history = []
        self.hits = 1
        self.age = 0
        
    def convert_bbox_to_z(self, bbox):
        """Convert bounding box to state vector"""
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        x = bbox[0] + w/2
        y = bbox[1] + h/2
        s = w * h
        r = w / float(h)
        return np.array([x, y, s, r]).reshape((4, 1))
    
    def convert_x_to_bbox(self):
        """Convert state vector to bounding box"""
        w = np.sqrt(self.kf.x[2] * self.kf.x[3])
        h = self.kf.x[2] / w
        x1 = self.kf.x[0] - w/2
        y1 = self.kf.x[1] - h/2
        x2 = self.kf.x[0] + w/2
        y2 = self.kf.x[1] + h/2
        return np.array([x1, y1, x2, y2]).reshape((1, 4))
    
    def predict(self):
        """Predict next state"""
        if (self.kf.x[6] + self.kf.x[2]) <= 0:
            self.kf.x[6] *= 0.0
        
        self.kf.predict()
        self.age += 1
        
        if self.time_since_update > 0:
            self.hits = 0
        
        self.time_since_update += 1
        self.history.append(self.convert_x_to_bbox())
        return self.history[-1]
    
    def update(self, bbox):
        """Update with new detection"""
        self.time_since_update = 0
        self.hits += 1
        self.kf.update(self.convert_bbox_to_z(bbox))
    
    def get_state(self):
        """Get current bounding box estimate"""
        return self.convert_x_to_bbox()


class BYTETracker:
    """BYTETracker implementation for vehicle tracking"""
    
    def __init__(self, config):
        self.config = config
        self.trackers = []
        self.frame_count = 0
        self.next_id = 1
        self.max_age = config['tracking']['max_age']
        self.min_hits = config['tracking']['min_hits']
        
    def update(self, detections):
        """Update tracker with new detections"""
        self.frame_count += 1
        
        # Separate high and low confidence detections
        high_conf = [d for d in detections if d['confidence'] > 0.5]
        low_conf = [d for d in detections if d['confidence'] <= 0.5]
        
        # Predict new locations
        for tracker in self.trackers:
            tracker.predict()
        
        # Match high confidence detections
        matched, unmatched_dets, unmatched_trks = self.match_detections(
            high_conf, self.trackers
        )
        
        # Update matched trackers
        for det_idx, trk_idx in matched:
            self.trackers[trk_idx].update(high_conf[det_idx]['bbox'])
        
        # Create new trackers for unmatched detections
        for i in unmatched_dets:
            bbox = high_conf[i]['bbox']
            class_id = high_conf[i]['class_id']
            tracker = KalmanBoxTracker(bbox, self.next_id, class_id)
            self.trackers.append(tracker)
            self.next_id += 1
        
        # Match low confidence detections with unmatched trackers
        if low_conf:
            unmatched_trk_indices = [i for i in unmatched_trks 
                                   if self.trackers[i].time_since_update == 1]
            low_matched, _, _ = self.match_detections(
                low_conf, [self.trackers[i] for i in unmatched_trk_indices]
            )
            
            for det_idx, trk_idx in low_matched:
                original_trk_idx = unmatched_trk_indices[trk_idx]
                self.trackers[original_trk_idx].update(low_conf[det_idx]['bbox'])
        
        # Remove dead trackers
        self.trackers = [t for t in self.trackers 
                        if not (t.time_since_update > self.max_age)]
        
        # Prepare output
        tracks = []
        for tracker in self.trackers:
            if tracker.time_since_update == 0 and tracker.hits >= self.min_hits:
                bbox = tracker.get_state()[0]
                tracks.append({
                    'id': tracker.id,
                    'bbox': bbox.tolist(),
                    'class_id': tracker.class_id,
                    'age': tracker.age
                })
        
        return tracks
    
    def match_detections(self, detections, trackers):
        """Hungarian algorithm for detection-tracker matching"""
        if len(trackers) == 0 or len(detections) == 0:
            return [], list(range(len(detections))), list(range(len(trackers)))
        
        # Calculate IoU matrix
        iou_matrix = np.zeros((len(detections), len(trackers)), dtype=np.float32)
        
        for d, det in enumerate(detections):
            for t, trk in enumerate(trackers):
                iou_matrix[d, t] = self.iou(det['bbox'], trk.get_state()[0])
        
        # Apply Hungarian algorithm
        matched_indices = linear_sum_assignment(-iou_matrix)
        matched_indices = list(zip(matched_indices[0], matched_indices[1]))
        
        # Filter matches with low IoU
        matches = []
        unmatched_detections = []
        unmatched_trackers = []
        
        for d in range(len(detections)):
            if d not in [m[0] for m in matched_indices]:
                unmatched_detections.append(d)
        
        for t in range(len(trackers)):
            if t not in [m[1] for m in matched_indices]:
                unmatched_trackers.append(t)
        
        for d, t in matched_indices:
            if iou_matrix[d, t] < 0.3:  # IoU threshold
                unmatched_detections.append(d)
                unmatched_trackers.append(t)
            else:
                matches.append((d, t))
        
        return matches, unmatched_detections, unmatched_trackers
    
    def iou(self, box1, box2):
        """Calculate Intersection over Union"""
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        if x2 < x1 or y2 < y1:
            return 0.0
        
        intersection = (x2 - x1) * (y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        
        return intersection / float(area1 + area2 - intersection)