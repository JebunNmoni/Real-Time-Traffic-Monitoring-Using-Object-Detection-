# main.py
import sys
import argparse
from pathlib import Path
from PyQt6.QtWidgets import QApplication
from src.gui.main_window import MainWindow
from src.detection.detector import VehicleDetector
from src.tracking.tracker import TrafficTracker

class TrafficMonitoringApp:
    def __init__(self, config_path="config/config.yaml"):
        self.config = self.load_config(config_path)
        self.detector = VehicleDetector(self.config)
        self.tracker = TrafficTracker(self.config)
        self.gui = None
        
    def load_config(self, path):
        import yaml
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    
    def run(self, video_source=0):
        """Run the application"""
        app = QApplication(sys.argv)
        self.gui = MainWindow(self.detector, self.tracker, self.config)
        self.gui.show()
        
        # Start processing if video source provided
        if video_source:
            self.gui.load_video(video_source)
        
        return app.exec()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Traffic Monitoring System")
    parser.add_argument("--video", type=str, help="Video file path or camera index")
    parser.add_argument("--config", type=str, default="config/config.yaml")
    args = parser.parse_args()
    
    app = TrafficMonitoringApp(args.config)
    sys.exit(app.run(args.video))