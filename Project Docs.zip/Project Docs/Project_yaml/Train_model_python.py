# train.py
from ultralytics import YOLO
import yaml

def train_model():
    # Load configuration
    with open('config/training_config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    
    # Load model
    model = YOLO(config['model']['pretrained'])
    
    # Train the model
    results = model.train(
        data=config['data']['path'],
        epochs=config['training']['epochs'],
        imgsz=config['model']['input_size'],
        batch=config['training']['batch_size'],
        device=config['training']['device'],
        patience=config['training']['patience'],
        lr0=config['training']['learning_rate'],
        augment=config['augmentation']['enabled'],
        hsv_h=config['augmentation']['hsv_h'],
        hsv_s=config['augmentation']['hsv_s'],
        hsv_v=config['augmentation']['hsv_v'],
        degrees=config['augmentation']['degrees'],
        translate=config['augmentation']['translate'],
        scale=config['augmentation']['scale'],
        shear=config['augmentation']['shear'],
        perspective=config['augmentation']['perspective'],
        flipud=config['augmentation']['flipud'],
        fliplr=config['augmentation']['fliplr'],
        mosaic=config['augmentation']['mosaic'],
        mixup=config['augmentation']['mixup'],
        copy_paste=config['augmentation']['copy_paste']
    )
    
    # Export model
    model.export(
        format=config['export']['format'],
        imgsz=config['model']['input_size'],
        device=config['training']['device'],
        half=config['export']['half_precision']
    )
    
    return results

if __name__ == "__main__":
    results = train_model()
    print("Training completed!")