# src/detection/detector.py
import cv2
import torch
import numpy as np
from typing import List, Tuple, Dict
import time

class VehicleDetector:
    def __init__(self, config):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = self.load_model()
        self.class_names = self.load_class_names()
        self.inference_time = 0
        self.frame_count = 0
        
    def load_model(self):
        """Load YOLOv8 model with TensorRT optimization"""
        from ultralytics import YOLO
        
        model_path = self.config['model']['path']
        if self.config['optimization']['use_tensorrt']:
            # Convert to TensorRT
            model = YOLO(model_path)
            model.export(format='engine', imgsz=640, device=self.device)
            model_path = model_path.replace('.pt', '.engine')
            
        model = YOLO(model_path)
        model.to(self.device)
        model.fuse()  # Fuse Conv2d + BatchNorm2d layers
        
        return model
    
    def load_class_names(self):
        """Load custom vehicle class names"""
        with open(self.config['model']['classes'], 'r') as f:
            return [line.strip() for line in f.readlines()]
    
    def preprocess(self, frame):
        """Preprocess frame for inference"""
        # Resize to model input size
        input_size = self.config['model']['input_size']
        frame_resized = cv2.resize(frame, input_size)
        
        # Convert BGR to RGB
        frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)
        
        # Normalize
        frame_normalized = frame_rgb / 255.0
        
        # Convert to tensor
        tensor = torch.from_numpy(frame_normalized).float().permute(2, 0, 1)
        tensor = tensor.unsqueeze(0).to(self.device)
        
        return tensor, frame_resized
    
    def detect(self, frame):
        """Perform object detection on a frame"""
        start_time = time.time()
        
        # Preprocess
        input_tensor, frame_resized = self.preprocess(frame)
        
        # Inference
        with torch.no_grad():
            if self.config['optimization']['half_precision']:
                input_tensor = input_tensor.half()
            predictions = self.model(input_tensor)[0]
        
        # Post-process detections
        detections = self.postprocess(predictions, frame.shape)
        
        # Calculate inference time
        self.inference_time = time.time() - start_time
        self.frame_count += 1
        
        return detections
    
    def postprocess(self, predictions, original_shape):
        """Convert model output to detection format"""
        detections = []
        original_h, original_w = original_shape[:2]
        
        if predictions is not None:
            for pred in predictions:
                if len(pred) >= 6:  # x1, y1, x2, y2, conf, class
                    x1, y1, x2, y2, conf, cls = pred[:6]
                    
                    # Scale to original image size
                    x1 = int(x1 * original_w / 640)
                    y1 = int(y1 * original_h / 480)
                    x2 = int(x2 * original_w / 640)
                    y2 = int(y2 * original_h / 480)
                    
                    # Filter by confidence
                    if conf > self.config['detection']['confidence_threshold']:
                        detections.append({
                            'bbox': [x1, y1, x2, y2],
                            'confidence': float(conf),
                            'class_id': int(cls),
                            'class_name': self.class_names[int(cls)]
                        })
        
        return detections
    
    def get_fps(self):
        """Calculate current FPS"""
        if self.inference_time > 0:
            return 1.0 / self.inference_time
        return 0