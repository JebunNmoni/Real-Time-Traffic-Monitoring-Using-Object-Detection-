# src/gui/main_window.py
import sys
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QPushButton, QLabel, 
                            QSlider, QComboBox, QGroupBox,
                            QSpinBox, QCheckBox, QTextEdit)
from PyQt6.QtCore import QTimer, Qt, pyqtSignal, QThread
from PyQt6.QtGui import QImage, QPixmap, QFont
import cv2
import numpy as np
import psutil
import GPUtil

class VideoThread(QThread):
    """Thread for video processing to avoid GUI freezing"""
    frame_processed = pyqtSignal(np.ndarray, list, dict)
    
    def __init__(self, detector, tracker):
        super().__init__()
        self.detector = detector
        self.tracker = tracker
        self.video_source = None
        self.is_running = False
        self.cap = None
        
    def set_video_source(self, source):
        self.video_source = source
        if self.cap:
            self.cap.release()
        self.cap = cv2.VideoCapture(source)
        
    def run(self):
        self.is_running = True
        while self.is_running and self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                break
            
            # Process frame
            detections = self.detector.detect(frame)
            tracks = self.tracker.update(detections)
            
            # Get performance metrics
            metrics = {
                'fps': self.detector.get_fps(),
                'detections': len(detections),
                'tracks': len(tracks),
                'inference_time': self.detector.inference_time
            }
            
            # Emit processed frame
            self.frame_processed.emit(frame, tracks, metrics)
            
        if self.cap:
            self.cap.release()
            
    def stop(self):
        self.is_running = False
        self.wait()


class MainWindow(QMainWindow):
    def __init__(self, detector, tracker, config):
        super().__init__()
        self.detector = detector
        self.tracker = tracker
        self.config = config
        
        self.init_ui()
        self.init_video_thread()
        
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("Traffic Monitoring System")
        self.setGeometry(100, 100, 1600, 900)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Left panel - Video display
        video_panel = QWidget()
        video_layout = QVBoxLayout(video_panel)
        
        # Video label
        self.video_label = QLabel()
        self.video_label.setMinimumSize(800, 600)
        self.video_label.setStyleSheet("border: 2px solid #333; background-color: black;")
        video_layout.addWidget(self.video_label)
        
        # Video controls
        control_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("Start")
        self.start_btn.clicked.connect(self.start_processing)
        
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.clicked.connect(self.stop_processing)
        self.stop_btn.setEnabled(False)
        
        self.record_btn = QPushButton("Record")
        self.record_btn.clicked.connect(self.toggle_recording)
        
        self.snapshot_btn = QPushButton("Snapshot")
        self.snapshot_btn.clicked.connect(self.take_snapshot)
        
        control_layout.addWidget(self.start_btn)
        control_layout.addWidget(self.stop_btn)
        control_layout.addWidget(self.record_btn)
        control_layout.addWidget(self.snapshot_btn)
        
        video_layout.addLayout(control_layout)
        
        # Right panel - Metrics and controls
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # Performance metrics group
        metrics_group = QGroupBox("Performance Metrics")
        metrics_layout = QVBoxLayout()
        
        self.fps_label = QLabel("FPS: 0.0")
        self.cpu_label = QLabel("CPU: 0%")
        self.gpu_label = QLabel("GPU: 0%")
        self.memory_label = QLabel("Memory: 0%")
        self.detection_label = QLabel("Detections: 0")
        self.track_label = QLabel("Active Tracks: 0")
        
        metrics_layout.addWidget(self.fps_label)
        metrics_layout.addWidget(self.cpu_label)
        metrics_layout.addWidget(self.gpu_label)
        metrics_layout.addWidget(self.memory_label)
        metrics_layout.addWidget(self.detection_label)
        metrics_layout.addWidget(self.track_label)
        
        metrics_group.setLayout(metrics_layout)
        right_layout.addWidget(metrics_group)
        
        # Detection controls group
        controls_group = QGroupBox("Detection Controls")
        controls_layout = QVBoxLayout()
        
        # Confidence threshold
        conf_layout = QHBoxLayout()
        conf_label = QLabel("Confidence:")
        self.conf_slider = QSlider(Qt.Orientation.Horizontal)
        self.conf_slider.setRange(10, 99)
        self.conf_slider.setValue(int(self.config['detection']['confidence_threshold'] * 100))
        self.conf_slider.valueChanged.connect(self.update_confidence)
        self.conf_value = QLabel(f"{self.conf_slider.value()}%")
        
        conf_layout.addWidget(conf_label)
        conf_layout.addWidget(self.conf_slider)
        conf_layout.addWidget(self.conf_value)
        controls_layout.addLayout(conf_layout)
        
        # Class filter
        class_layout = QHBoxLayout()
        class_label = QLabel("Show Classes:")
        self.class_combo = QComboBox()
        self.class_combo.addItems(["All", "Cars Only", "Trucks Only", "Buses Only"])
        self.class_combo.currentTextChanged.connect(self.update_class_filter)
        
        class_layout.addWidget(class_label)
        class_layout.addWidget(self.class_combo)
        controls_layout.addLayout(class_layout)
        
        # Display options
        self.show_bbox = QCheckBox("Show Bounding Boxes", checked=True)
        self.show_labels = QCheckBox("Show Labels", checked=True)
        self.show_tracks = QCheckBox("Show Tracks", checked=True)
        self.show_ids = QCheckBox("Show IDs", checked=True)
        
        controls_layout.addWidget(self.show_bbox)
        controls_layout.addWidget(self.show_labels)
        controls_layout.addWidget(self.show_tracks)
        controls_layout.addWidget(self.show_ids)
        
        controls_group.setLayout(controls_layout)
        right_layout.addWidget(controls_group)
        
        # Traffic statistics group
        stats_group = QGroupBox("Traffic Statistics")
        stats_layout = QVBoxLayout()
        
        self.stats_text = QTextEdit()
        self.stats_text.setReadOnly(True)
        self.stats_text.setMaximumHeight(200)
        
        stats_layout.addWidget(self.stats_text)
        stats_group.setLayout(stats_layout)
        right_layout.addWidget(stats_group)
        
        # Add stretch at the end
        right_layout.addStretch()
        
        # Add panels to main layout
        main_layout.addWidget(video_panel, 70)
        main_layout.addWidget(right_panel, 30)
        
        # Setup update timer for metrics
        self.metrics_timer = QTimer()
        self.metrics_timer.timeout.connect(self.update_metrics)
        self.metrics_timer.start(1000)  # Update every second
        
        # Recording variables
        self.is_recording = False
        self.video_writer = None
        
    def init_video_thread(self):
        """Initialize the video processing thread"""
        self.video_thread = VideoThread(self.detector, self.tracker)
        self.video_thread.frame_processed.connect(self.update_frame)
        
    def update_frame(self, frame, tracks, metrics):
        """Update the video display with processed frame"""
        # Draw annotations
        annotated_frame = self.draw_annotations(frame, tracks)
        
        # Convert to QImage
        height, width, channels = annotated_frame.shape
        bytes_per_line = channels * width
        q_img = QImage(annotated_frame.data, width, height, 
                      bytes_per_line, QImage.Format.Format_RGB888)
        
        # Update video label
        pixmap = QPixmap.fromImage(q_img)
        scaled_pixmap = pixmap.scaled(self.video_label.size(), 
                                     Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation)
        self.video_label.setPixmap(scaled_pixmap)
        
        # Update metrics
        self.current_metrics = metrics
        
        # Record if enabled
        if self.is_recording and self.video_writer:
            self.video_writer.write(cv2.cvtColor(annotated_frame, cv2.COLOR_RGB2BGR))
    
    def draw_annotations(self, frame, tracks):
        """Draw bounding boxes, labels, and IDs on frame"""
        # Convert BGR to RGB
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Draw tracks
        for track in tracks:
            bbox = track['bbox']
            track_id = track['id']
            class_id = track['class_id']
            
            # Draw bounding box
            if self.show_bbox.isChecked():
                color = self.get_color(track_id)
                cv2.rectangle(frame_rgb, 
                            (int(bbox[0]), int(bbox[1])),
                            (int(bbox[2]), int(bbox[3])),
                            color, 2)
            
            # Draw label and ID
            if self.show_labels.isChecked() or self.show_ids.isChecked():
                label_parts = []
                if self.show_labels.isChecked():
                    label_parts.append(self.detector.class_names[class_id])
                if self.show_ids.isChecked():
                    label_parts.append(f"ID: {track_id}")
                
                label = " | ".join(label_parts)
                
                # Calculate text position
                text_x = int(bbox[0])
                text_y = int(bbox[1]) - 10 if int(bbox[1]) > 20 else int(bbox[3]) + 20
                
                # Draw text background
                text_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
                cv2.rectangle(frame_rgb,
                            (text_x, text_y - text_size[1] - 4),
                            (text_x + text_size[0], text_y + 4),
                            (0, 0, 0), -1)
                
                # Draw text
                cv2.putText(frame_rgb, label,
                          (text_x, text_y),
                          cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                          (255, 255, 255), 2)
        
        return frame_rgb
    
    def get_color(self, track_id):
        """Generate consistent color for track ID"""
        # Simple hash-based color generation
        r = (track_id * 50) % 255
        g = (track_id * 100) % 255
        b = (track_id * 150) % 255
        return (int(r), int(g), int(b))
    
    def update_metrics(self):
        """Update performance metrics display"""
        if hasattr(self, 'current_metrics'):
            # Update FPS and detection counts
            self.fps_label.setText(f"FPS: {self.current_metrics['fps']:.1f}")
            self.detection_label.setText(f"Detections: {self.current_metrics['detections']}")
            self.track_label.setText(f"Active Tracks: {self.current_metrics['tracks']}")
            
            # Update system metrics
            cpu_percent = psutil.cpu_percent()
            memory_percent = psutil.virtual_memory().percent
            self.cpu_label.setText(f"CPU: {cpu_percent:.1f}%")
            self.memory_label.setText(f"Memory: {memory_percent:.1f}%")
            
            # Update GPU metrics if available
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    self.gpu_label.setText(f"GPU: {gpu.load*100:.1f}% ({gpu.temperature}°C)")
            except:
                self.gpu_label.setText("GPU: N/A")
            
            # Update traffic statistics
            self.update_traffic_stats()
    
    def update_traffic_stats(self):
        """Update traffic statistics display"""
        stats_text = "=== Traffic Statistics ===\n\n"
        
        # Count vehicles by type
        vehicle_counts = {}
        for track in self.tracker.tracks:
            if hasattr(track, 'class_id'):
                class_name = self.detector.class_names[track.class_id]
                vehicle_counts[class_name] = vehicle_counts.get(class_name, 0) + 1
        
        for vehicle_type, count in vehicle_counts.items():
            stats_text += f"{vehicle_type}: {count}\n"
        
        self.stats_text.setText(stats_text)
    
    def start_processing(self):
        """Start video processing"""
        # Open file dialog or use default camera
        if not self.video_thread.cap:
            # Try default camera
            self.video_thread.set_video_source(0)
        
        if self.video_thread.cap and self.video_thread.cap.isOpened():
            self.video_thread.start()
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
    
    def stop_processing(self):
        """Stop video processing"""
        self.video_thread.stop()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        
        # Stop recording if active
        if self.is_recording:
            self.toggle_recording()
    
    def toggle_recording(self):
        """Toggle video recording"""
        if not self.is_recording:
            # Start recording
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            output_path = f"recording_{time.strftime('%Y%m%d_%H%M%S')}.mp4"
            self.video_writer = cv2.VideoWriter(
                output_path, fourcc, 30.0, 
                (self.video_label.width(), self.video_label.height())
            )
            self.is_recording = True
            self.record_btn.setText("Stop Recording")
            self.record_btn.setStyleSheet("background-color: red; color: white;")
        else:
            # Stop recording
            if self.video_writer:
                self.video_writer.release()
                self.video_writer = None
            self.is_recording = False
            self.record_btn.setText("Record")
            self.record_btn.setStyleSheet("")
    
    def take_snapshot(self):
        """Take a snapshot of the current frame"""
        if hasattr(self.video_thread, 'current_frame'):
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filename = f"snapshot_{timestamp}.jpg"
            cv2.imwrite(filename, self.video_thread.current_frame)
            print(f"Snapshot saved as {filename}")
    
    def update_confidence(self, value):
        """Update confidence threshold"""
        confidence = value / 100.0
        self.detector.config['detection']['confidence_threshold'] = confidence
        self.conf_value.setText(f"{value}%")
    
    def update_class_filter(self, text):
        """Update class filter settings"""
        # Update detection filter based on selection
        pass
    
    def closeEvent(self, event):
        """Handle window close event"""
        self.stop_processing()
        if self.video_writer:
            self.video_writer.release()
        event.accept()