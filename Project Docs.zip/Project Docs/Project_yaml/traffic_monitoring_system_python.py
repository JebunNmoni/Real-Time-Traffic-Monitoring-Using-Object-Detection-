"""
traffic_monitoring_system/
├── main.py
├── requirements.txt
├── config/
│   ├── config.yaml
│   └── classes.txt
├── src/
│   ├── detection/
│   │   ├── __init__.py
│   │   ├── detector.py
│   │   ├── model_loader.py
│   │   └── optimizer.py
│   ├── tracking/
│   │   ├── __init__.py
│   │   ├── tracker.py
│   │   ├── byte_track.py
│   │   └── kalman_filter.py
│   ├── gui/
│   │   ├── __init__.py
│   │   ├── main_window.py
│   │   ├── video_widget.py
│   │   ├── control_panel.py
│   │   └── metrics_display.py
│   └── utils/
│       ├── __init__.py
│       ├── video_processor.py
│       ├── annotations.py
│       ├── logger.py
│       └── performance.py
├── models/
│   ├── yolov8n.pt
│   └── yolov8n_tensorrt.engine
├── data/
│   ├── raw_videos/
│   ├── processed/
│   └── annotations/
└── tests/
    ├── test_detection.py
    └── test_tracking.py
"""